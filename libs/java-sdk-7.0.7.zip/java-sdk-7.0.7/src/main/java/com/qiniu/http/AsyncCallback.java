package com.qiniu.http;

/**
 * Created by bailong on 15/10/8.
 */
public interface AsyncCallback {
    void complete(Response r);
}
