package com.qiniu.storage;

/**
 * Created by bailong on 15/10/8.
 */
public class AsyncResumeUploader {
}
