package com.qiniu.storage.model;

/**
 * Created by bailong on 15/2/23.
 */
public class ResumeBlockInfo {
    public String ctx;
    public long crc32;
}
